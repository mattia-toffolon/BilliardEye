import cv2

# Open the video file
video_path = './render.avi'
cap = cv2.VideoCapture(video_path)

# Check if the video was opened successfully
if not cap.isOpened():
    print("Error: Could not open video.")
    exit()

# Read and display frames in a loop
while True:
    ret, frame = cap.read()

    # Break the loop if there are no more frames to read
    if not ret:
        break

    # Display the frame
    cv2.imshow('Video Frame', frame)

    # Wait for 25 ms and check if the 'q' key is pressed to exit the loop
    if cv2.waitKey(0) & 0xFF == ord('q'):
        break

# Release the video capture object and close all OpenCV windows
cap.release()
cv2.destroyAllWindows()
